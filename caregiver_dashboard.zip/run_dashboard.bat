@echo off
title CogniSolace - Caregiver Dashboard
echo ====================================================
echo        🧠 COGNISOLACE CAREGIVER DASHBOARD
echo ====================================================
echo.
echo Opening Caregiver Dashboard in your default browser...
echo.
start index.html
echo.
echo If your FastAPI backend is running on port 8000, 
echo live patient data and photo uploads will sync automatically!
echo.
pause
