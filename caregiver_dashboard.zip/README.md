# 🧠 CogniSolace — Caregiver & Healthcare Dashboard (Member 6)

The **Caregiver Dashboard** is designed for families, doctors, and healthcare workers to monitor an elderly patient's cognitive health, track daily routine adherence, and upload personalized reminiscence media (family photos and voice notes).

---

## 🚀 How to Run the Dashboard

### Option 1: Direct Double-Click (Zero Setup / Instant Preview)
- Simply double-click **`index.html`** or **`run_dashboard.bat`**.
- It opens in Google Chrome, Microsoft Edge, or any modern web browser.
- **Auto-Detect Feature:**
  - If the CogniSolace FastAPI backend is running on `http://localhost:8000`, the badge displays:  
    `🟢 Live Backend Connected` and displays real-time telemetry from the database.
  - If the backend is not running, it automatically switches to:  
    `🟡 Standalone Preview Mode` with complete sample patient charts, routine checklists, and interactive photo cards.

### Option 2: Run with FastAPI Backend
If you are integrating with Member 5 (FastAPI + SQLite):
```powershell
# From the cognisolace project root:
python run_server.py
```
Open your browser at:
`http://localhost:8000/dashboard`

### Option 3: Deploy to the Web (Vercel / Netlify / GitHub Pages)
- Simply drag-and-drop this entire folder onto [Netlify Drop](https://app.netlify.com/drop) or push to GitHub Pages.
- `index.html` is a fully responsive Single Page Application (SPA) with Chart.js included.

---

## 📊 Core Features Implemented

1. **Cognitive Performance Trends:**
   - Visual Memory Recall % (from Photo Memory Matching).
   - Sequence Attention % (from Color Sequence Memory).
   - 7-Day Moving Average trend indicators (`↑ Improving`, `→ Stable`, `↓ Attention Needed`).
2. **Clinical Anomaly Alerts:**
   - Automatic triggers if visual recall accuracy dips $> 20\%$ or if routine adherence is missed.
3. **Reminiscence Personalization Management:**
   - Upload family photos (labeled e.g., *"Granddaughter Priya"*, *"Pet Bruno"*).
   - Add spoken prompts and voice notes for encouragement.
   - Automatically feeds into the Senior Memory Matching game.
4. **Daily Routine & Medicine Tracker:**
   - Checklist for morning blood pressure tablets, hydration, and gentle walks.
   - One-click completion toggles.
